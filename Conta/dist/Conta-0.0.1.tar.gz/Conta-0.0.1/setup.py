from setuptools import setup, find_packages

setup(
    name='Conta',
    version='0.0.1',
    description='Módulo que representa a classe Conta do sistema bancário',
    packages=find_packages(),
    install_requires=[],
)
